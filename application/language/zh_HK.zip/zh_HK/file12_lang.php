<?php
$lang['special_characters_not_allowed']='你的店鋪名稱不能包含特別字符';  ?>